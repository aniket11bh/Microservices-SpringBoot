package demo;

import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping(value="/dept")
public class DeptController {

	
	@Autowired
	private DeptRepository repo;
    private List<Dept> list = new ArrayList<Dept>();
	
    @PostConstruct
    public void inserttest(){
    	for (int i = 100;i < 160;i+=10)
    	{
    		Dept d  = new Dept();
    		d.setDeptno(i);
    		d.setDname("Siemens" + i);
    		if( (i%20)==0)
    				d.setLoc("Mubmai");
    		else
    			d.setLoc("BLR");
    		repo.save(d);
    	}
    }
    
	@GetMapping()
    public List<Dept> list() {
		
        System.out.println("in list " + list.size());
        return repo.findAll();
    }
	   
    
}