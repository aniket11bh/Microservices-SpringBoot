package hello;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
@RequestMapping(value="/")
public class HelloController {

    @GetMapping()
    public String index() {
        return "<h1>Hello World </h1>";
    }
    
    @GetMapping(value="/add1")
    public String add(@RequestParam(name="nm")String name, @RequestParam(name="nm1")String name1) {
        return "<h1>Hello World , name = " + (name +  name1) + "</h1> ";
    }
 
    @GetMapping(value="/add2")
    public String add(@RequestParam(name="n1")int no1, @RequestParam(name="n2")int no2) {
        return "<h1>Hello World , name = " + (no1+no2) + "</h1> ";
    }
    
    
    @PostMapping
    public String index1() {
        return "<h1>Hello World In POST MApping</h1>";
    }
}