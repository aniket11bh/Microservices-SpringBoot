package demo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(value="/")
public class MyController {
	@GetMapping(value="/insert")
	public String insert(){
		return "<h1>Insert</h1><h2><a href='/' >Home</a></h2>";
	}
	@GetMapping(value="/list")
	public String list(){
		return "<h1>List</h1><h2><a href='/' >Home</a></h2>";
	}
}
